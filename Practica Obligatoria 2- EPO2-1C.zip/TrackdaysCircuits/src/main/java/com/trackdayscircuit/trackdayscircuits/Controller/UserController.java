package com.trackdayscircuit.trackdayscircuits.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import jakarta.servlet.http.HttpSession;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import java.util.HashMap;
import java.util.Map;

//Clase de control spring
@Controller
public class UserController {

    // Metodo para agregar el usuario actual a los modelos de las vistas
    private void agregarUsuarioActual(HttpSession session, Model model) {
        String usuario = (String) session.getAttribute("Usuario_Actual");
        model.addAttribute("Usuario_Actual", usuario);
    }

    @GetMapping("/")
    public String home(HttpSession session, Model model) {
        String usuario = (String) session.getAttribute("Usuario_Actual");
        model.addAttribute("Usuario_Actual", usuario);
        return "index";
    }

    @GetMapping("/login")
    public String mostrarpantallalogin(HttpSession session, Model model) {
        agregarUsuarioActual(session, model);
        return "login";
    }


    @GetMapping("/index")
    public String home2(HttpSession session, Model model) {
        agregarUsuarioActual(session, model);
        return "index";
    }

    @GetMapping("/pokemon")
    public String about(HttpSession session, Model model) {
        agregarUsuarioActual(session, model);
        return "pokemon"; // Carga templates/about.html
    }


    @GetMapping("/circuits")
    public String listacircuitos(HttpSession session, Model model) {
        agregarUsuarioActual(session, model);
        return "circuits";
    }

    @Autowired
    private RestTemplate restTemplate;

    @PostMapping("/login")
    public String login(@RequestParam String username,
                        @RequestParam String password,
                        HttpSession session,
                        Model model) {

        // Crear el JSON para enviar a Flask
        Map<String, String> credentials = new HashMap<>();
        credentials.put("username", username);
        credentials.put("password", password);

        // Preparar la llamada HTTP con la cabecera JSON
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Map<String, String>> request = new HttpEntity<>(credentials, headers);

        try {
            // Llamo al endpoint del backend Flask
            ResponseEntity<Boolean> response = restTemplate.postForEntity(
                    "http://localhost:5000/Trackdayscircuits-api/login", request, Boolean.class);

            if (Boolean.TRUE.equals(response.getBody())) {
                // Login exitoso y guardo el usuario
                session.setAttribute("Usuario_Actual", username);
                return "redirect:/";

            } else {
                // Si no es correcto muestro el error en la pantalla del login
                model.addAttribute("error", "Usuario o contraseña incorrectos.");
                return "login";
            }

        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al conectar con el servidor.");
            return "login";
        }
    }

    @GetMapping("/buscarPokemon")
    public String buscarPokemon(@RequestParam("nombre") String nombre, Model model) {

        String url = "http://localhost:5000/Trackdayscircuits-api/pokemon/" + nombre;
        try {
            // Llamada a la API Flask que a su vez llama a la de pokemon
            ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);
            model.addAttribute("pokemon", response.getBody());

        } catch (HttpClientErrorException.NotFound e) {
            model.addAttribute("error", "Pokémon no encontrado");
        } catch (Exception e) {
            model.addAttribute("error", "Error al consultar la API");
        }
        //Vuelve a la vista pokemon con el pokemon o el error
        return "pokemon";
    }

}

