import csv
import requests
from flask import Flask, jsonify, request
import mysql.connector
from mysql.connector import Error, IntegrityError, ProgrammingError, InterfaceError
import time

app = Flask(__name__)

#Configuración de conexión a la bbdd
db_config = {
    "host": "mysql", #nombre del contenedor al usar docker
    "port": 3306,
    "user": "myuser",
    "password": "secret",
    "database": "bbddCircuits"
}
#Metodo para leer el fichero csv con los usuarios
def leer_fichero(ruta_csv):
    usuarios = []
    try:
        with open(ruta_csv, mode='r', encoding='utf-8') as archivo:
            datos = csv.reader(archivo, delimiter=',')
            for fila in datos:
                if len(fila) != 3:
                    print(f"Fila inválida (se esperan 3 campos): {fila}")
                    continue
                usuario, password, email = fila
                usuarios.append((usuario.strip(), password.strip(), email.strip()))
    except FileNotFoundError:
        print(f"El archivo {ruta_csv} no existe.")
    except IOError as e:
        print(f"Error al leer el archivo {ruta_csv}: {e}")
    except Exception as e:
        print(f"Error inesperado leyendo el archivo: {e}")
    return usuarios

def crear_admin():

    conn = None
    try:
        # Leo los usuarios del CSV
        usuarios = leer_fichero('./usuarios.csv')
        if not usuarios:
            print("No se han encontrado usuarios en el archivo.")
            return

        #creo el conector
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()

        #Creo la tabla de usuarios si no existe
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS usuarios (
                id INT AUTO_INCREMENT PRIMARY KEY,
                usuario VARCHAR(255),
                password VARCHAR(255),
                email VARCHAR(255)
            )
        """)

        #Compruebo si existe el usuario y si no existe lo creo
        for usuario, password, email in usuarios:
            cursor.execute("SELECT COUNT(*) FROM usuarios WHERE usuario = %s", (usuario,))
            if cursor.fetchone()[0] == 0:
                cursor.execute(
                    "INSERT INTO usuarios (usuario, password, email) VALUES (%s, %s, %s)",
                    (usuario, password, email)
                )
                conn.commit()
                print(f"Usuario {usuario} insertado.")
            else:
                print(f"Usuario {usuario} ya existe.")
    except Error as e:
        print(f"Error creando el usuario admin: {e}")
    finally:
        #Si la conexion esta abierta la cierro
        if conn is not None and conn.is_connected():
            cursor.close()
            conn.close()


#Para poder crear el usuario he tenido que hacer este metodo para esperar hasta que la bbdd este activa, ya que sino la pimera vez
#que inicio la aplicacion ejecuta el crear el usuario demasiado rapido y no le da tiempo a estar activa la bbdd
def esperar_mysql():
    for i in range(10):
        try:
            conn = mysql.connector.connect(**db_config)
            if conn.is_connected():
                conn.close()
                return
        except Error as e:
            print(f"Esperando MySQL... intento {i+1}, error: {e}")
            time.sleep(5)

# metodo Post para verificar que el usuario exite en la bbdd
@app.route('/Trackdayscircuits-api/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')
    password = data.get('password')

    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM usuarios WHERE usuario = %s AND password = %s",
                       (username, password))
        user = cursor.fetchone()
    #si el usuario existe el json se envia con true sino con false
        if user:
            return jsonify(True)
        else:
            return jsonify(False)
    #Las excepciones que conozco
    except IntegrityError as e:
        return jsonify({"error": "Violación de integridad", "detalles": str(e)}), 409
    except ProgrammingError as e:
        return jsonify({"error": "Error de sintaxis en la base de datos", "detalles": str(e)}), 400
    except InterfaceError as e:
        return jsonify({"error": "Problema de conexión con la base de datos", "detalles": str(e)}), 503
    except Exception as e:
        return jsonify({"error": "Error inesperado", "detalles": str(e)}), 500
    finally:
        if conn.is_connected():
            cursor.close()
            conn.close()

#Metodo get con la API externa Pokemon
@app.route("/Trackdayscircuits-api/pokemon/<nombre>", methods=["GET"])
def get_pokemon(nombre):
    url = f"https://pokeapi.co/api/v2/pokemon/{nombre.lower()}"
    try:
        response = requests.get(url) #hago el request a la url del API
        response.raise_for_status()
        data = response.json()
        resultado = { #saco los resultados del response y los convierto en el json
            "nombre": data["name"],
            "imagen": data["sprites"]["front_default"],
            "tipos": [t["type"]["name"] for t in data["types"]],
            "peso": data["weight"],
            "altura": data["height"]
        }
        return jsonify(resultado) #devuelvo el json con lo datos del pokemon buscado

    #Las excepciones que conozco
    except requests.exceptions.HTTPError:
        return jsonify({"error": "Pokémon no encontrado"}), 404

    except requests.exceptions.ConnectionError:
        return jsonify({"error": "Error de conexión con la API externa"}), 503

    except requests.exceptions.Timeout:
        return jsonify({"error": "La API de Pokémon tardó demasiado en responder"}), 504

    except requests.exceptions.RequestException as e:
        # Captura cualquier otro error relacionado con requests
        return jsonify({"error": "Error en la solicitud a la API externa", "detalles": str(e)}), 500

    except ValueError:
        return jsonify({"error": "Error interpretando la respuesta JSON"}), 500

    except Exception as e:
        return jsonify({"error": "Error inesperado", "detalles": str(e)}), 500

if __name__ == "__main__":
    esperar_mysql()
    crear_admin()
    #acceso en la red para docker
    app.run(host='0.0.0.0', port=5000)